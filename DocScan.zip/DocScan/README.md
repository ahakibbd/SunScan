# DocScan – স্ক্যানার অ্যাপ (ClearScanner স্টাইল)

## ফিচার
- My Docs তালিকা (নাম, সাইজ, পৃষ্ঠা সংখ্যা, তারিখ), সার্চ, রিনেম, ডিলিট
- ক্যামেরা ও গ্যালারি থেকে স্ক্যান (গ্যালারি থেকে একসাথে অনেক ছবি)
- Border adjustment: ৪ কোণা টেনে ক্রপ ও পার্সপেক্টিভ সোজা করা, রোটেট
- ফিল্টার: Original, Photo, Docs, Clear, Color
- ডকুমেন্টে আরও পৃষ্ঠা যোগ, পৃষ্ঠা সিলেক্ট করে Delete / Move / Copy / Collage / Share
- PDF বা JPG হিসেবে শেয়ার, ফাইলের নাম ও সাইজ (Actual/Medium/Small), Downloads-এ সেভ
- কোনো বিজ্ঞাপন নেই, ইন্টারনেট পারমিশনও নেই

## APK বানানোর নিয়ম

### পথ ১: GitHub Actions (পিসি ছাড়াই)
1. github.com-এ নতুন একটি repository খুলুন (যেমন `DocScan`)।
2. এই ফোল্ডারের সব ফাইল (`.github` ফোল্ডারসহ) repository-তে আপলোড করুন।
3. **Actions** ট্যাবে `Build APK` চালু হবে (না হলে **Run workflow** চাপুন)। ৩–৬ মিনিট লাগে।
4. কাজ শেষ হলে ওই রানে ঢুকে নিচে **Artifacts → DocScan-APK** ডাউনলোড করুন।
5. জিপ খুলে `app-debug.apk` ফোনে ইনস্টল করুন (Unknown sources অনুমতি দিতে হবে)।

### পথ ২: Android Studio (পিসিতে)
1. Android Studio-তে **Open** দিয়ে এই ফোল্ডারটি খুলুন, Gradle sync শেষ হতে দিন।
2. **Build → Build Bundle(s) / APK(s) → Build APK(s)**।
3. APK পাবেন `app/build/outputs/apk/debug/app-debug.apk`-এ।

## অ্যাপের ধরন
- minSdk 29 (Android 10 বা তার উপরে), Kotlin, প্লেইন Android Views
- নির্ভরতা মাত্র তিনটি: core-ktx, appcompat, recyclerview
