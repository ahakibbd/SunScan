package com.docscan.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint

object Filters {
    val names = listOf("Original", "Photo", "Docs", "Clear", "Color")

    fun process(src: Bitmap, mode: Int): Bitmap = when (mode) {
        0 -> src
        1 -> colorMatrix(src, 1.08f, 1.10f)
        2 -> normalize(src, true)
        3 -> normalize(src, false)
        else -> colorMatrix(src, 1.40f, 1.15f)
    }

    private fun colorMatrix(src: Bitmap, saturation: Float, contrast: Float): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val sat = ColorMatrix()
        sat.setSaturation(saturation)
        val t = (-0.5f * contrast + 0.5f) * 255f
        val con = ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, t,
                0f, contrast, 0f, 0f, t,
                0f, 0f, contrast, 0f, t,
                0f, 0f, 0f, 1f, 0f
            )
        )
        sat.postConcat(con)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        paint.colorFilter = ColorMatrixColorFilter(sat)
        Canvas(out).drawBitmap(src, 0f, 0f, paint)
        return out
    }

    private fun level(x: Int, lo: Int, range: Int): Int = ((x - lo) * 255 / range).coerceIn(0, 255)

    /**
     * Removes shadows / uneven lighting by dividing every pixel by an estimate of the local
     * paper colour, then stretches the levels. gray = true gives a black & white "Docs" look,
     * gray = false keeps ink colours ("Clear").
     */
    private fun normalize(src: Bitmap, gray: Boolean): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)

        val cell = maxOf(12, maxOf(w, h) / 48)
        val gw = (w + cell - 1) / cell
        val gh = (h + cell - 1) / cell
        val mr = IntArray(gw * gh)
        val mg = IntArray(gw * gh)
        val mb = IntArray(gw * gh)

        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                val p = px[y * w + x]
                val gi = (y / cell) * gw + (x / cell)
                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val b = p and 255
                if (r > mr[gi]) mr[gi] = r
                if (g > mg[gi]) mg[gi] = g
                if (b > mb[gi]) mb[gi] = b
                x += 2
            }
            y += 2
        }

        val gp = IntArray(gw * gh)
        for (j in 0 until gh) {
            for (i in 0 until gw) {
                var sr = 0
                var sg = 0
                var sb = 0
                var n = 0
                for (dj in -1..1) {
                    for (di in -1..1) {
                        val jj = j + dj
                        val ii = i + di
                        if (jj in 0 until gh && ii in 0 until gw) {
                            val k = jj * gw + ii
                            sr += mr[k]
                            sg += mg[k]
                            sb += mb[k]
                            n++
                        }
                    }
                }
                gp[j * gw + i] = (0xFF shl 24) or ((sr / n) shl 16) or ((sg / n) shl 8) or (sb / n)
            }
        }

        val gridBmp = Bitmap.createBitmap(gp, gw, gh, Bitmap.Config.ARGB_8888)
        val bgBmp = Bitmap.createScaledBitmap(gridBmp, w, h, true)
        val bp = IntArray(w * h)
        bgBmp.getPixels(bp, 0, w, 0, 0, w, h)

        val lo = if (gray) 70 else 45
        val hi = if (gray) 205 else 225
        val range = hi - lo

        for (i in px.indices) {
            val p = px[i]
            val q = bp[i]
            val r = ((p shr 16) and 255) * 255 / maxOf(1, (q shr 16) and 255)
            val g = ((p shr 8) and 255) * 255 / maxOf(1, (q shr 8) and 255)
            val b = (p and 255) * 255 / maxOf(1, q and 255)
            if (gray) {
                val v = level((r * 30 + g * 59 + b * 11) / 100, lo, range)
                px[i] = (0xFF shl 24) or (v shl 16) or (v shl 8) or v
            } else {
                px[i] = (0xFF shl 24) or
                    (level(r, lo, range) shl 16) or
                    (level(g, lo, range) shl 8) or
                    level(b, lo, range)
            }
        }

        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }
}
