package com.docscan.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import kotlin.math.min

/** Shows a picture with four draggable corner handles (border adjustment). */
class CropView(c: Context) : View(c) {
    private var bmp: Bitmap? = null
    private val pts = FloatArray(8) // TL, TR, BR, BL as x,y pairs in bitmap coordinates
    private var active = -1
    private var scale = 1f
    private var ox = 0f
    private var oy = 0f

    private val handleR = Ui.dp(c, 14).toFloat()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00C800")
        style = Paint.Style.STROKE
        strokeWidth = Ui.dp(c, 2).toFloat()
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#9900C800")
        style = Paint.Style.FILL
    }
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)

    init {
        setBackgroundColor(Color.BLACK)
    }

    fun setBitmap(b: Bitmap) {
        bmp = b
        inset(0.04f)
    }

    fun bitmap(): Bitmap? = bmp

    fun corners(): FloatArray = pts.copyOf()

    fun inset(f: Float) {
        val b = bmp ?: return
        val x = b.width * f
        val y = b.height * f
        val r = b.width - x
        val bt = b.height - y
        pts[0] = x; pts[1] = y
        pts[2] = r; pts[3] = y
        pts[4] = r; pts[5] = bt
        pts[6] = x; pts[7] = bt
        invalidate()
    }

    fun full() = inset(0f)

    override fun onDraw(canvas: Canvas) {
        val b = bmp ?: return
        scale = min(width / b.width.toFloat(), height / b.height.toFloat())
        ox = (width - b.width * scale) / 2f
        oy = (height - b.height * scale) / 2f
        canvas.save()
        canvas.translate(ox, oy)
        canvas.scale(scale, scale)
        canvas.drawBitmap(b, 0f, 0f, bmpPaint)
        canvas.restore()

        val path = Path()
        for (i in 0..3) {
            val x = ox + pts[i * 2] * scale
            val y = oy + pts[i * 2 + 1] * scale
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        canvas.drawPath(path, line)
        for (i in 0..3) {
            canvas.drawCircle(ox + pts[i * 2] * scale, oy + pts[i * 2 + 1] * scale, handleR, dot)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val b = bmp ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                var best = -1
                var bestD = Float.MAX_VALUE
                for (i in 0..3) {
                    val dx = ox + pts[i * 2] * scale - e.x
                    val dy = oy + pts[i * 2 + 1] * scale - e.y
                    val d = dx * dx + dy * dy
                    if (d < bestD) {
                        bestD = d
                        best = i
                    }
                }
                val reach = handleR * 3.5f
                active = if (bestD < reach * reach) best else -1
            }
            MotionEvent.ACTION_MOVE -> {
                if (active >= 0) {
                    pts[active * 2] = ((e.x - ox) / scale).coerceIn(0f, b.width.toFloat())
                    pts[active * 2 + 1] = ((e.y - oy) / scale).coerceIn(0f, b.height.toFloat())
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> active = -1
        }
        return true
    }
}
