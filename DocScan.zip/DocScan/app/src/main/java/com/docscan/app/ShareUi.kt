package com.docscan.app

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import java.io.File

/** "Share" dialog: .pdf or .jpg, file name, file size, then share or save to Downloads. */
object ShareUi {

    fun show(a: Activity, name: String, pages: List<File>) {
        if (pages.isEmpty()) {
            Ui.toast(a, "No pages")
            return
        }
        val fmt = Spinner(a)
        fmt.adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, listOf(".pdf", ".jpg"))
        val nameEt = EditText(a)
        nameEt.setText(name.replace(Regex("[\\\\/:*?\"<>|]"), "_"))
        nameEt.setSingleLine()
        val sizeSp = Spinner(a)
        sizeSp.adapter = ArrayAdapter(
            a, android.R.layout.simple_spinner_dropdown_item,
            listOf("Actual", "Medium", "Small")
        )

        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(Ui.dp(a, 20), Ui.dp(a, 8), Ui.dp(a, 20), 0)
        box.addView(row(a, "Share as:", fmt))
        box.addView(row(a, "Filename:", nameEt))
        box.addView(row(a, "File Size:", sizeSp))

        AlertDialog.Builder(a)
            .setTitle("Share")
            .setView(box)
            .setPositiveButton("Share") { _, _ ->
                run(a, pages, nameEt.text.toString(), fmt.selectedItemPosition == 0, sizeSp.selectedItemPosition, true)
            }
            .setNeutralButton("Save to Downloads") { _, _ ->
                run(a, pages, nameEt.text.toString(), fmt.selectedItemPosition == 0, sizeSp.selectedItemPosition, false)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun row(a: Activity, label: String, v: View): LinearLayout {
        val r = LinearLayout(a)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = android.view.Gravity.CENTER_VERTICAL
        val t = TextView(a)
        t.text = label
        t.layoutParams = LinearLayout.LayoutParams(Ui.dp(a, 90), Ui.WRAP)
        r.addView(t)
        r.addView(v, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        return r
    }

    private fun run(a: Activity, pages: List<File>, rawName: String, pdf: Boolean, sizeIdx: Int, share: Boolean) {
        val fname = rawName.trim().ifEmpty { "Document" }
        Ui.toast(a, "Preparing...")
        Thread {
            try {
                val files = build(a, pages, fname, pdf, sizeIdx)
                a.runOnUiThread { if (share) send(a, files, pdf) else save(a, files, pdf) }
            } catch (e: Throwable) {
                a.runOnUiThread { Ui.toast(a, "Failed: " + e.message) }
            }
        }.start()
    }

    private fun build(a: Activity, pages: List<File>, fname: String, pdf: Boolean, sizeIdx: Int): List<File> {
        val dir = File(a.cacheDir, "share")
        dir.deleteRecursively()
        dir.mkdirs()
        val maxDim = when (sizeIdx) {
            0 -> 2000
            1 -> 1400
            else -> 900
        }
        val quality = when (sizeIdx) {
            0 -> 92
            1 -> 70
            else -> 50
        }
        if (pdf) {
            val doc = PdfDocument()
            pages.forEachIndexed { i, f ->
                val b = Img.decode(f.absolutePath, maxDim) ?: return@forEachIndexed
                val pw = 595
                val ph = (pw * b.height.toFloat() / b.width).toInt().coerceAtLeast(1)
                val info = PdfDocument.PageInfo.Builder(pw, ph, i + 1).create()
                val page = doc.startPage(info)
                page.canvas.drawBitmap(b, null, Rect(0, 0, pw, ph), Paint(Paint.FILTER_BITMAP_FLAG))
                doc.finishPage(page)
                b.recycle()
            }
            val out = File(dir, "$fname.pdf")
            out.outputStream().use { doc.writeTo(it) }
            doc.close()
            return listOf(out)
        }
        return pages.mapIndexed { i, f ->
            val b = Img.decode(f.absolutePath, maxDim) ?: throw IllegalStateException("Cannot read page ${i + 1}")
            val out = File(dir, if (pages.size == 1) "$fname.jpg" else "${fname}_${i + 1}.jpg")
            out.outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, quality, it) }
            b.recycle()
            out
        }
    }

    private fun send(a: Activity, files: List<File>, pdf: Boolean) {
        val uris = files.map { FileProvider.getUriForFile(a, a.packageName + ".fileprovider", it) }
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
        }
        intent.type = if (pdf) "application/pdf" else "image/jpeg"
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        a.startActivity(Intent.createChooser(intent, "Share"))
    }

    private fun save(a: Activity, files: List<File>, pdf: Boolean) {
        try {
            for (f in files) {
                val v = ContentValues()
                v.put(MediaStore.Downloads.DISPLAY_NAME, f.name)
                v.put(MediaStore.Downloads.MIME_TYPE, if (pdf) "application/pdf" else "image/jpeg")
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                val u = a.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                    ?: throw IllegalStateException("Cannot create file")
                a.contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
            }
            Ui.toast(a, "Saved to Downloads")
        } catch (e: Throwable) {
            Ui.toast(a, "Failed: " + e.message)
        }
    }
}
