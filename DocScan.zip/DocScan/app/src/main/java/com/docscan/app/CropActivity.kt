package com.docscan.app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import java.io.File

/** Step 1: "Border adjustment" - drag the corners, rotate, confirm. */
class CropActivity : AppCompatActivity() {
    private lateinit var cv: CropView
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c: Context = this
        Ui.statusBar(this)

        val path = intent.getStringExtra("path")
        if (path == null) {
            finish()
            return
        }
        val bmp = Img.decode(path, 2000)
        if (bmp == null) {
            Ui.toast(c, "Cannot open image")
            Flow.queue.clear()
            finish()
            return
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                Flow.queue.clear()
                finish()
            }
        })

        cv = CropView(c)
        cv.setBitmap(bmp)

        val root = LinearLayout(c)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.BLACK)

        val head = Ui.header(c)
        head.addView(Ui.icon(c, R.drawable.ic_back) {
            Flow.queue.clear()
            finish()
        })
        head.addView(Ui.title(c, "Border adjustment"))
        root.addView(head, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        root.addView(cv, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))

        val bar = Ui.bottomBar(c)
        bar.addView(Ui.icon(c, R.drawable.ic_shrink) { cv.inset(0.04f) })
        bar.addView(Ui.icon(c, R.drawable.ic_fullscreen) { cv.full() })
        bar.addView(Ui.icon(c, R.drawable.ic_rotate_left) { rotate(-90f) })
        bar.addView(Ui.icon(c, R.drawable.ic_rotate_right) { rotate(90f) })
        val spacer = View(c)
        bar.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        bar.addView(Ui.icon(c, R.drawable.ic_check) { confirm() })
        root.addView(bar, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        setContentView(root)
    }

    private fun rotate(deg: Float) {
        val b = cv.bitmap() ?: return
        cv.setBitmap(Img.rotate(b, deg))
    }

    private fun confirm() {
        if (busy) return
        val src = cv.bitmap() ?: return
        busy = true
        val corners = cv.corners()
        Thread {
            try {
                val out: Bitmap = Img.warp(src, corners)
                val f = File(cacheDir, "crop_" + System.currentTimeMillis() + ".jpg")
                f.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                runOnUiThread {
                    startActivity(Intent(this, FilterActivity::class.java).putExtra("path", f.absolutePath))
                    finish()
                }
            } catch (e: Throwable) {
                runOnUiThread {
                    busy = false
                    Ui.toast(this, "Failed: " + e.message)
                }
            }
        }.start()
    }
}
