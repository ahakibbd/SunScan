package com.docscan.app

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.LruCache
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

object Ui {
    val BAR: Int = Color.parseColor("#21474B")
    val ACCENT: Int = Color.parseColor("#00897B")
    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun statusBar(a: Activity) {
        a.window.statusBarColor = Color.parseColor("#183538")
    }

    fun toast(c: Context, msg: String) {
        Toast.makeText(c, msg, Toast.LENGTH_SHORT).show()
    }

    fun fmtSize(b: Long): String =
        if (b >= 1048576L) String.format(Locale.ENGLISH, "%.2f MB", b / 1048576.0)
        else "${maxOf(1L, b / 1024)} KB"

    fun fmtDate(ms: Long): String =
        SimpleDateFormat("MMM-dd, HH:mm", Locale.ENGLISH).format(Date(ms))

    private fun ripple(c: Context): Drawable? {
        val a = c.obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackgroundBorderless))
        val d = a.getDrawable(0)
        a.recycle()
        return d
    }

    fun icon(c: Context, res: Int, tint: Int = Color.WHITE, size: Int = 48, onClick: (View) -> Unit): ImageView {
        val iv = ImageView(c)
        iv.setImageResource(res)
        iv.setColorFilter(tint)
        val p = dp(c, 12)
        iv.setPadding(p, p, p, p)
        iv.layoutParams = LinearLayout.LayoutParams(dp(c, size), dp(c, size))
        iv.background = ripple(c)
        iv.setOnClickListener { v -> onClick(v) }
        return iv
    }

    fun header(c: Context): LinearLayout {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        l.setBackgroundColor(BAR)
        l.setPadding(dp(c, 4), 0, dp(c, 4), 0)
        l.minimumHeight = dp(c, 56)
        return l
    }

    fun bottomBar(c: Context): LinearLayout {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        l.setBackgroundColor(BAR)
        l.setPadding(dp(c, 8), 0, dp(c, 8), 0)
        l.minimumHeight = dp(c, 60)
        return l
    }

    fun title(c: Context, text: String): TextView {
        val t = TextView(c)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        t.setPadding(dp(c, 8), 0, dp(c, 8), 0)
        t.layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        return t
    }

    fun barButton(c: Context, iconRes: Int, label: String, onClick: () -> Unit): TextView {
        val t = TextView(c)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        t.gravity = Gravity.CENTER
        val d = ContextCompat.getDrawable(c, iconRes)!!.mutate()
        d.setTint(Color.WHITE)
        d.setBounds(0, 0, dp(c, 24), dp(c, 24))
        t.setCompoundDrawables(null, d, null, null)
        t.compoundDrawablePadding = dp(c, 2)
        t.setPadding(0, dp(c, 8), 0, dp(c, 8))
        t.layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        t.background = ripple(c)
        t.setOnClickListener { onClick() }
        return t
    }

    fun boxed(c: Context, text: String, color: Int): TextView {
        val t = TextView(c)
        t.text = text
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        t.setTextColor(color)
        val g = GradientDrawable()
        g.setStroke(dp(c, 1), color)
        g.cornerRadius = dp(c, 3).toFloat()
        t.background = g
        t.setPadding(dp(c, 5), dp(c, 1), dp(c, 5), dp(c, 1))
        return t
    }

    fun prompt(a: Activity, title: String, initial: String, onOk: (String) -> Unit) {
        val et = EditText(a)
        et.setText(initial)
        et.setSingleLine()
        et.setSelection(et.text.length)
        val box = LinearLayout(a)
        box.setPadding(dp(a, 20), dp(a, 8), dp(a, 20), 0)
        box.addView(et, LinearLayout.LayoutParams(MATCH, WRAP))
        AlertDialog.Builder(a)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                val s = et.text.toString().trim()
                if (s.isNotEmpty()) onOk(s)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}

/** Small async thumbnail loader with an in-memory cache. */
object Thumbs {
    private val cache = LruCache<String, Bitmap>(60)
    private val pool = Executors.newFixedThreadPool(2)
    private val handler = Handler(Looper.getMainLooper())

    fun load(iv: ImageView, f: File, maxDim: Int) {
        val key = f.absolutePath + "@" + f.lastModified()
        iv.tag = key
        val hit = cache.get(key)
        if (hit != null) {
            iv.setImageBitmap(hit)
            return
        }
        iv.setImageDrawable(null)
        pool.execute {
            val b = Img.decode(f.absolutePath, maxDim) ?: return@execute
            cache.put(key, b)
            handler.post { if (iv.tag == key) iv.setImageBitmap(b) }
        }
    }
}
