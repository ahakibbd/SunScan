package com.docscan.app

import android.net.Uri
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File

/** Shared camera / gallery launchers for the screens that can start a new scan. */
abstract class ScanBase : AppCompatActivity() {
    private var targetDoc: String? = null
    private var camFile: File? = null

    private val pick = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) Flow.begin(this, uris, targetDoc)
    }

    private val cam = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = camFile
        if (ok && f != null) Flow.begin(this, listOf(Uri.fromFile(f)), targetDoc)
    }

    fun openGallery(doc: String?) {
        targetDoc = doc
        pick.launch("image/*")
    }

    fun openCamera(doc: String?) {
        targetDoc = doc
        val f = File(cacheDir, "cam_" + System.currentTimeMillis() + ".jpg")
        camFile = f
        cam.launch(FileProvider.getUriForFile(this, "$packageName.fileprovider", f))
    }
}
