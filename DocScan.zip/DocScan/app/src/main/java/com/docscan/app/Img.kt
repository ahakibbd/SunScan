package com.docscan.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.media.ExifInterface
import kotlin.math.hypot
import kotlin.math.max

object Img {

    /** Decodes a picture, applies the EXIF rotation and limits the longest side to maxDim. */
    fun decode(path: String, maxDim: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > maxDim * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var b = BitmapFactory.decodeFile(path, opts) ?: return null
        val deg = exifDegrees(path)
        if (deg != 0) b = rotate(b, deg.toFloat())
        val m = max(b.width, b.height)
        if (m > maxDim) {
            val k = maxDim.toFloat() / m
            b = Bitmap.createScaledBitmap(
                b,
                (b.width * k).toInt().coerceAtLeast(1),
                (b.height * k).toInt().coerceAtLeast(1),
                true
            )
        }
        return b
    }

    private fun exifDegrees(path: String): Int = try {
        when (ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90
            ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
    } catch (e: Exception) {
        0
    }

    fun rotate(b: Bitmap, deg: Float): Bitmap {
        val m = Matrix()
        m.postRotate(deg)
        return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }

    fun shrink(b: Bitmap, maxDim: Int): Bitmap {
        val m = max(b.width, b.height)
        if (m <= maxDim) return b
        val k = maxDim.toFloat() / m
        return Bitmap.createScaledBitmap(
            b,
            (b.width * k).toInt().coerceAtLeast(1),
            (b.height * k).toInt().coerceAtLeast(1),
            true
        )
    }

    /**
     * Perspective-corrects the quadrilateral [c] (TL, TR, BR, BL as x,y pairs in bitmap
     * coordinates) into an upright rectangle.
     */
    fun warp(src: Bitmap, c: FloatArray): Bitmap {
        val top = hypot(c[2] - c[0], c[3] - c[1])
        val bottom = hypot(c[4] - c[6], c[5] - c[7])
        val left = hypot(c[6] - c[0], c[7] - c[1])
        val right = hypot(c[4] - c[2], c[5] - c[3])
        val w = max(top, bottom).toInt().coerceIn(32, 4000)
        val h = max(left, right).toInt().coerceIn(32, 4000)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val dst = floatArrayOf(0f, 0f, w.toFloat(), 0f, w.toFloat(), h.toFloat(), 0f, h.toFloat())
        val m = Matrix()
        m.setPolyToPoly(c, 0, dst, 0, 4)
        Canvas(out).drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }
}
