package com.docscan.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

/** Step 2: pick Original / Photo / Docs / Clear / Color, rotate, then save the page. */
class FilterActivity : AppCompatActivity() {
    private var base: Bitmap? = null
    private var small: Bitmap? = null
    private var mode = 3
    private val cache = HashMap<Int, Bitmap>()
    private val tabs = ArrayList<TextView>()
    private lateinit var iv: ImageView
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c: Context = this
        Ui.statusBar(this)

        val path = intent.getStringExtra("path")
        val loaded = if (path != null) Img.decode(path, 2000) else null
        if (loaded == null) {
            Flow.queue.clear()
            finish()
            return
        }
        base = loaded
        small = Img.shrink(loaded, 1000)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                Flow.queue.clear()
                finish()
            }
        })

        val root = LinearLayout(c)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#E5E5E5"))

        val top = Ui.header(c)
        top.setPadding(0, 0, 0, 0)
        Filters.names.forEachIndexed { i, n ->
            val t = TextView(c)
            t.text = n
            t.setTextColor(Color.WHITE)
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            t.gravity = Gravity.CENTER
            t.layoutParams = LinearLayout.LayoutParams(0, Ui.dp(c, 56), 1f)
            t.setOnClickListener { setMode(i) }
            tabs.add(t)
            top.addView(t)
        }
        root.addView(top, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        iv = ImageView(c)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.setPadding(Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8))
        root.addView(iv, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))

        val bar = Ui.bottomBar(c)
        bar.addView(Ui.icon(c, R.drawable.ic_rotate_left) { rotate(-90f) })
        bar.addView(Ui.icon(c, R.drawable.ic_rotate_right) { rotate(90f) })
        bar.addView(View(c), LinearLayout.LayoutParams(0, 1, 1f))
        bar.addView(Ui.icon(c, R.drawable.ic_check) { save() })
        root.addView(bar, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        setContentView(root)
        setMode(3)
    }

    private fun setMode(m: Int) {
        mode = m
        tabs.forEachIndexed { i, t -> t.setBackgroundColor(if (i == m) 0x33FFFFFF else 0) }
        val cached = cache[m]
        if (cached != null) {
            iv.setImageBitmap(cached)
            return
        }
        val src = small ?: return
        Thread {
            val r = Filters.process(src, m)
            runOnUiThread {
                cache[m] = r
                if (mode == m) iv.setImageBitmap(r)
            }
        }.start()
    }

    private fun rotate(deg: Float) {
        val b = base ?: return
        val rb = Img.rotate(b, deg)
        base = rb
        small = Img.shrink(rb, 1000)
        cache.clear()
        setMode(mode)
    }

    private fun save() {
        if (busy) return
        val b = base ?: return
        busy = true
        Ui.toast(this, "Saving...")
        val m = mode
        Thread {
            try {
                val out = Filters.process(b, m)
                val existing = Flow.docId?.let { Store.get(this, it) }
                val doc = existing ?: Store.create(this).also { Flow.docId = it.id }
                Store.addPage(doc, out)
                runOnUiThread { Flow.finishStep(this) }
            } catch (e: Throwable) {
                runOnUiThread {
                    busy = false
                    Ui.toast(this, "Failed: " + e.message)
                }
            }
        }.start()
    }
}
