package com.docscan.app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** "My Docs (N)" - the list of scanned documents. */
class MainActivity : ScanBase() {
    private lateinit var titleTv: TextView
    private lateinit var search: EditText
    private lateinit var empty: TextView
    private lateinit var rv: RecyclerView
    private var docs: List<Doc> = emptyList()
    private var query = ""
    private val adapter = DocAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c: Context = this
        Ui.statusBar(this)

        val root = LinearLayout(c)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.WHITE)

        val head = Ui.header(c)
        titleTv = Ui.title(c, "My Docs")
        head.addView(titleTv)
        head.addView(Ui.icon(c, R.drawable.ic_search) {
            search.visibility = if (search.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            if (search.visibility == View.GONE) search.setText("")
        })
        head.addView(Ui.icon(c, R.drawable.ic_more) { anchor ->
            val pm = PopupMenu(c, anchor)
            pm.menu.add("About")
            pm.setOnMenuItemClickListener {
                AlertDialog.Builder(c)
                    .setTitle("DocScan")
                    .setMessage("Scan documents with the camera or gallery, adjust borders, apply filters and share as PDF or JPG.")
                    .setPositiveButton("OK", null)
                    .show()
                true
            }
            pm.show()
        })
        root.addView(head, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        search = EditText(c)
        search.hint = "Search"
        search.setSingleLine()
        search.visibility = View.GONE
        search.setPadding(Ui.dp(c, 16), Ui.dp(c, 8), Ui.dp(c, 16), Ui.dp(c, 8))
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, co: Int, af: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, co: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString()?.trim().orEmpty()
                refresh()
            }
        })
        root.addView(search, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        val frame = FrameLayout(c)
        rv = RecyclerView(c)
        rv.layoutManager = LinearLayoutManager(c)
        rv.adapter = adapter
        rv.addItemDecoration(DividerItemDecoration(c, DividerItemDecoration.VERTICAL))
        frame.addView(rv, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        empty = TextView(c)
        empty.text = "No documents yet.\nTap the camera or gallery button below to scan."
        empty.gravity = Gravity.CENTER
        empty.setTextColor(Color.GRAY)
        empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        frame.addView(empty, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        root.addView(frame, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))

        val bar = Ui.bottomBar(c)
        bar.gravity = Gravity.CENTER
        bar.addView(Ui.icon(c, R.drawable.ic_image, size = 64) { openGallery(null) })
        bar.addView(Ui.icon(c, R.drawable.ic_camera, size = 64) { openCamera(null) })
        root.addView(bar, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val all = Store.all(this)
        titleTv.text = "My Docs (" + all.size + ")"
        docs = if (query.isEmpty()) all else all.filter { it.name.contains(query, ignoreCase = true) }
        empty.visibility = if (docs.isEmpty()) View.VISIBLE else View.GONE
        adapter.notifyDataSetChanged()
    }

    private fun open(d: Doc) {
        startActivity(Intent(this, DocActivity::class.java).putExtra("id", d.id))
    }

    private fun menu(anchor: View, d: Doc) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add("Open")
        pm.menu.add("Rename")
        pm.menu.add("Share")
        pm.menu.add("Delete")
        pm.setOnMenuItemClickListener { item ->
            when (item.title.toString()) {
                "Open" -> open(d)
                "Rename" -> Ui.prompt(this, "Rename", d.name) {
                    Store.rename(d, it)
                    refresh()
                }
                "Share" -> ShareUi.show(this, d.name, d.pages)
                "Delete" -> AlertDialog.Builder(this)
                    .setMessage("Delete \"" + d.name + "\"?")
                    .setPositiveButton("Delete") { _, _ ->
                        Store.deleteDoc(d)
                        refresh()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            true
        }
        pm.show()
    }

    private inner class DocAdapter : RecyclerView.Adapter<DocAdapter.VH>() {
        inner class VH(
            val root: LinearLayout,
            val iv: ImageView,
            val name: TextView,
            val size: TextView,
            val count: TextView,
            val date: TextView,
            val more: ImageView
        ) : RecyclerView.ViewHolder(root)

        override fun getItemCount() = docs.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val c: Context = this@MainActivity
            val row = LinearLayout(c)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(Ui.dp(c, 12), Ui.dp(c, 12), Ui.dp(c, 4), Ui.dp(c, 12))
            row.layoutParams = RecyclerView.LayoutParams(Ui.MATCH, Ui.WRAP)

            val iv = ImageView(c)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setBackgroundColor(Color.parseColor("#EEEEEE"))
            row.addView(iv, LinearLayout.LayoutParams(Ui.dp(c, 88), Ui.dp(c, 62)))

            val col = LinearLayout(c)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(Ui.dp(c, 16), 0, Ui.dp(c, 8), 0)
            val name = TextView(c)
            name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            name.setTextColor(Color.parseColor("#222222"))
            name.maxLines = 1
            name.ellipsize = android.text.TextUtils.TruncateAt.END
            col.addView(name)
            val info = LinearLayout(c)
            info.orientation = LinearLayout.HORIZONTAL
            info.gravity = Gravity.CENTER_VERTICAL
            val size = TextView(c)
            size.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            size.setTextColor(Color.GRAY)
            info.addView(size)
            val count = Ui.boxed(c, "1", Color.GRAY)
            val lp = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
            lp.leftMargin = Ui.dp(c, 10)
            info.addView(count, lp)
            col.addView(info)
            val date = TextView(c)
            date.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            date.setTextColor(Color.GRAY)
            col.addView(date)
            row.addView(col, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))

            val more = Ui.icon(c, R.drawable.ic_more, tint = Color.DKGRAY) { }
            row.addView(more)
            return VH(row, iv, name, size, count, date, more)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val d = docs[position]
            val pages = d.pages
            h.name.text = d.name
            h.size.text = Ui.fmtSize(d.size)
            h.count.text = pages.size.toString()
            h.date.text = Ui.fmtDate(d.modified)
            if (pages.isNotEmpty()) Thumbs.load(h.iv, pages[0], 300) else h.iv.setImageDrawable(null)
            h.root.setOnClickListener { open(d) }
            h.more.setOnClickListener { menu(h.more, d) }
        }
    }
}
