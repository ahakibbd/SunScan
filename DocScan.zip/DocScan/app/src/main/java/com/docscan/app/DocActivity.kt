package com.docscan.app

import android.app.Dialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.util.Locale

/** One document: a grid of its pages, with multi-select actions. */
class DocActivity : ScanBase() {
    private lateinit var id: String
    private var doc: Doc? = null
    private var pages: List<File> = emptyList()
    private val selected = LinkedHashSet<String>()

    private lateinit var titleTv: TextView
    private lateinit var normalBar: LinearLayout
    private lateinit var selBar: LinearLayout
    private lateinit var rv: RecyclerView
    private val adapter = PageAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c: Context = this
        Ui.statusBar(this)

        val docId = intent.getStringExtra("id")
        if (docId == null) {
            finish()
            return
        }
        id = docId

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (selected.isNotEmpty()) {
                    selected.clear()
                    update()
                } else {
                    finish()
                }
            }
        })

        val root = LinearLayout(c)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#E5E5E5"))

        val head = Ui.header(c)
        head.addView(Ui.icon(c, R.drawable.ic_back) {
            if (selected.isNotEmpty()) {
                selected.clear()
                update()
            } else {
                finish()
            }
        })
        titleTv = Ui.title(c, "")
        titleTv.setOnClickListener {
            val d = doc
            if (d != null && selected.isEmpty()) {
                Ui.prompt(this, "Rename", d.name) {
                    Store.rename(d, it)
                    update()
                }
            }
        }
        head.addView(titleTv)
        head.addView(Ui.icon(c, R.drawable.ic_pdf) {
            val d = doc
            if (d != null) ShareUi.show(this, d.name, d.pages)
        })
        head.addView(Ui.icon(c, R.drawable.ic_more) { anchor -> headMenu(anchor) })
        root.addView(head, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        rv = RecyclerView(c)
        rv.layoutManager = GridLayoutManager(c, 3)
        rv.adapter = adapter
        rv.setPadding(Ui.dp(c, 4), Ui.dp(c, 4), Ui.dp(c, 4), Ui.dp(c, 4))
        rv.clipToPadding = false
        root.addView(rv, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))

        normalBar = Ui.bottomBar(c)
        normalBar.gravity = Gravity.CENTER
        normalBar.addView(Ui.icon(c, R.drawable.ic_image, size = 64) { openGallery(id) })
        normalBar.addView(Ui.icon(c, R.drawable.ic_camera, size = 64) { openCamera(id) })
        root.addView(normalBar, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        selBar = Ui.bottomBar(c)
        selBar.setPadding(0, 0, 0, 0)
        selBar.addView(Ui.barButton(c, R.drawable.ic_delete, "Delete") { deleteSelected() })
        selBar.addView(Ui.barButton(c, R.drawable.ic_move, "Move") { moveSelected() })
        selBar.addView(Ui.barButton(c, R.drawable.ic_copy, "Copy") { copySelected() })
        selBar.addView(Ui.barButton(c, R.drawable.ic_collage, "Collage") { collageSelected() })
        selBar.addView(Ui.barButton(c, R.drawable.ic_share, "Share") { shareSelected() })
        root.addView(selBar, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val d = Store.get(this, id)
        if (d == null) {
            finish()
            return
        }
        doc = d
        pages = d.pages
        val live = pages.map { it.absolutePath }.toSet()
        selected.retainAll(live)
        update()
    }

    private fun update() {
        val d = doc ?: return
        val sel = selected.isNotEmpty()
        titleTv.text = if (sel) selected.size.toString() + " Selected" else d.name
        normalBar.visibility = if (sel) View.GONE else View.VISIBLE
        selBar.visibility = if (sel) View.VISIBLE else View.GONE
        adapter.notifyDataSetChanged()
    }

    private fun picked(): List<File> = pages.filter { it.absolutePath in selected }

    private fun headMenu(anchor: View) {
        val d = doc ?: return
        val pm = PopupMenu(this, anchor)
        pm.menu.add("Rename")
        pm.menu.add("Select all")
        pm.menu.add("Delete document")
        pm.setOnMenuItemClickListener { item ->
            when (item.title.toString()) {
                "Rename" -> Ui.prompt(this, "Rename", d.name) {
                    Store.rename(d, it)
                    update()
                }
                "Select all" -> {
                    pages.forEach { selected.add(it.absolutePath) }
                    update()
                }
                "Delete document" -> AlertDialog.Builder(this)
                    .setMessage("Delete \"" + d.name + "\"?")
                    .setPositiveButton("Delete") { _, _ ->
                        Store.deleteDoc(d)
                        finish()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            true
        }
        pm.show()
    }

    private fun afterChange() {
        selected.clear()
        val d = Store.get(this, id)
        if (d == null || d.pages.isEmpty()) {
            if (d != null) Store.deleteDoc(d)
            finish()
        } else {
            refresh()
        }
    }

    private fun deleteSelected() {
        val files = picked()
        if (files.isEmpty()) return
        AlertDialog.Builder(this)
            .setMessage("Delete " + files.size + " page(s)?")
            .setPositiveButton("Delete") { _, _ ->
                files.forEach { it.delete() }
                afterChange()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun moveSelected() {
        val files = picked()
        if (files.isEmpty()) return
        val others = Store.all(this).filter { it.id != id }
        val labels = (listOf("+ New document") + others.map { it.name }).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Move to")
            .setItems(labels) { _, which ->
                val target = if (which == 0) Store.create(this) else others[which - 1]
                files.forEach { f ->
                    val nf = Store.newPageFile(target)
                    if (!f.renameTo(nf)) {
                        f.copyTo(nf, overwrite = true)
                        f.delete()
                    }
                }
                afterChange()
            }
            .show()
    }

    private fun copySelected() {
        val d = doc ?: return
        val files = picked()
        if (files.isEmpty()) return
        files.forEach { Store.copyPage(d, it) }
        selected.clear()
        refresh()
        Ui.toast(this, "Copied")
    }

    private fun collageSelected() {
        val d = doc ?: return
        val files = picked()
        if (files.size < 2) {
            Ui.toast(this, "Select at least 2 pages")
            return
        }
        if (files.size > 8) {
            Ui.toast(this, "Select up to 8 pages")
            return
        }
        Ui.toast(this, "Creating collage...")
        Thread {
            try {
                val w = 1200
                val scaled = files.mapNotNull { Img.decode(it.absolutePath, 2000) }.map { b ->
                    val h = (b.height * w / b.width.toFloat()).toInt().coerceAtLeast(1)
                    Bitmap.createScaledBitmap(b, w, h, true)
                }
                val total = scaled.sumOf { it.height }
                val out = Bitmap.createBitmap(w, total, Bitmap.Config.ARGB_8888)
                val cv = Canvas(out)
                cv.drawColor(Color.WHITE)
                var y = 0f
                for (b in scaled) {
                    cv.drawBitmap(b, 0f, y, null)
                    y += b.height
                }
                Store.addPage(d, out)
                runOnUiThread {
                    selected.clear()
                    refresh()
                }
            } catch (e: Throwable) {
                runOnUiThread { Ui.toast(this, "Failed: " + e.message) }
            }
        }.start()
    }

    private fun shareSelected() {
        val d = doc ?: return
        ShareUi.show(this, d.name, picked())
    }

    private fun preview(f: File) {
        val dlg = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val iv = ImageView(this)
        iv.setBackgroundColor(Color.BLACK)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.setImageBitmap(Img.decode(f.absolutePath, 2000))
        iv.setOnClickListener { dlg.dismiss() }
        dlg.setContentView(iv)
        dlg.show()
    }

    private inner class PageAdapter : RecyclerView.Adapter<PageAdapter.VH>() {
        inner class VH(
            val root: FrameLayout,
            val iv: ImageView,
            val num: TextView,
            val info: TextView,
            val check: ImageView
        ) : RecyclerView.ViewHolder(root)

        override fun getItemCount() = pages.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val c: Context = this@DocActivity
            val m = Ui.dp(c, 4)
            val cellW = (c.resources.displayMetrics.widthPixels - Ui.dp(c, 32)) / 3
            val root = FrameLayout(c)
            root.setBackgroundColor(Color.WHITE)
            val lp = RecyclerView.LayoutParams(cellW, (cellW * 1.35f).toInt())
            lp.setMargins(m, m, m, m)
            root.layoutParams = lp

            val iv = ImageView(c)
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            root.addView(iv, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))

            val strip = LinearLayout(c)
            strip.orientation = LinearLayout.HORIZONTAL
            strip.gravity = Gravity.CENTER_VERTICAL
            strip.setBackgroundColor(Color.parseColor("#99444444"))
            strip.setPadding(Ui.dp(c, 4), Ui.dp(c, 6), Ui.dp(c, 4), Ui.dp(c, 6))
            val num = Ui.boxed(c, "01", Color.WHITE)
            strip.addView(num)
            val info = TextView(c)
            info.setTextColor(Color.WHITE)
            info.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            info.setPadding(Ui.dp(c, 6), 0, 0, 0)
            strip.addView(info, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
            val check = ImageView(c)
            check.setImageResource(R.drawable.ic_check)
            check.setColorFilter(Color.WHITE)
            check.visibility = View.GONE
            strip.addView(check, LinearLayout.LayoutParams(Ui.dp(c, 20), Ui.dp(c, 20)))
            root.addView(strip, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.BOTTOM))
            return VH(root, iv, num, info, check)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val c: Context = this@DocActivity
            val f = pages[position]
            val isSel = f.absolutePath in selected
            Thumbs.load(h.iv, f, 400)
            h.num.text = String.format(Locale.ENGLISH, "%02d", position + 1)
            h.info.text = Ui.fmtSize(f.length())
            h.check.visibility = if (isSel) View.VISIBLE else View.GONE
            if (isSel) {
                val g = GradientDrawable()
                g.setStroke(Ui.dp(c, 3), Ui.ACCENT)
                g.setColor(Color.TRANSPARENT)
                h.root.foreground = g
            } else {
                h.root.foreground = null
            }
            h.root.setOnClickListener {
                if (selected.isNotEmpty()) toggle(f) else preview(f)
            }
            h.root.setOnLongClickListener {
                toggle(f)
                true
            }
        }

        private fun toggle(f: File) {
            val p = f.absolutePath
            if (!selected.add(p)) selected.remove(p)
            update()
        }
    }
}
