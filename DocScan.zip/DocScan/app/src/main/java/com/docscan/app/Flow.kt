package com.docscan.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import java.io.File

/**
 * Drives the "pick image -> crop -> filter -> save page" pipeline, including several
 * images picked at once from the gallery.
 */
object Flow {
    val queue = ArrayDeque<Uri>()
    var docId: String? = null
    var openDocAtEnd = false

    fun begin(a: Activity, uris: List<Uri>, doc: String?) {
        queue.clear()
        queue.addAll(uris)
        docId = doc
        openDocAtEnd = doc == null
        if (!next(a)) openDocAtEnd = false
    }

    private fun next(a: Activity): Boolean {
        while (true) {
            val u = queue.removeFirstOrNull() ?: return false
            val f = File(a.cacheDir, "src_" + System.currentTimeMillis() + ".jpg")
            try {
                a.contentResolver.openInputStream(u)!!.use { input ->
                    f.outputStream().use { input.copyTo(it) }
                }
            } catch (e: Exception) {
                continue
            }
            a.startActivity(Intent(a, CropActivity::class.java).putExtra("path", f.absolutePath))
            return true
        }
    }

    /** Called by the filter screen after a page was saved. */
    fun finishStep(a: Activity) {
        if (!next(a)) {
            val id = docId
            if (openDocAtEnd && id != null) {
                a.startActivity(Intent(a, DocActivity::class.java).putExtra("id", id))
            }
            openDocAtEnd = false
        }
        a.finish()
    }
}
