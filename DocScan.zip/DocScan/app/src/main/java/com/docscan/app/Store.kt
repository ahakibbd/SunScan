package com.docscan.app

import android.content.Context
import android.graphics.Bitmap
import java.io.File
import java.util.Locale

class Doc(val id: String, val dir: File) {
    val name: String
        get() {
            val f = File(dir, "name.txt")
            val t = if (f.exists()) f.readText().trim() else ""
            return t.ifEmpty { id }
        }
    val pages: List<File>
        get() = dir.listFiles { f -> f.name.startsWith("page_") && f.name.endsWith(".jpg") }
            ?.sortedBy { it.name } ?: emptyList()
    val size: Long get() = pages.sumOf { it.length() }
    val modified: Long get() = pages.maxOfOrNull { it.lastModified() } ?: dir.lastModified()
}

object Store {
    private var seq = 0L

    private fun root(ctx: Context): File = File(ctx.filesDir, "docs").also { it.mkdirs() }

    fun all(ctx: Context): List<Doc> =
        root(ctx).listFiles { f -> f.isDirectory }
            ?.map { Doc(it.name, it) }
            ?.sortedByDescending { it.modified } ?: emptyList()

    fun get(ctx: Context, id: String): Doc? {
        val d = File(root(ctx), id)
        return if (d.isDirectory) Doc(id, d) else null
    }

    fun create(ctx: Context): Doc {
        val sp = ctx.getSharedPreferences("store", Context.MODE_PRIVATE)
        val n = sp.getInt("next", 1)
        sp.edit().putInt("next", n + 1).apply()
        val id = "d" + System.currentTimeMillis()
        val dir = File(root(ctx), id)
        dir.mkdirs()
        File(dir, "name.txt").writeText("Document $n")
        return Doc(id, dir)
    }

    @Synchronized
    fun newPageFile(doc: Doc): File {
        seq++
        val name = String.format(Locale.ROOT, "page_%013d_%04d.jpg", System.currentTimeMillis(), seq % 10000)
        return File(doc.dir, name)
    }

    fun addPage(doc: Doc, bmp: Bitmap): File {
        val f = newPageFile(doc)
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        return f
    }

    fun copyPage(doc: Doc, src: File): File {
        val f = newPageFile(doc)
        src.copyTo(f, overwrite = true)
        return f
    }

    fun rename(doc: Doc, name: String) {
        File(doc.dir, "name.txt").writeText(name)
    }

    fun deleteDoc(doc: Doc) {
        doc.dir.deleteRecursively()
    }
}
